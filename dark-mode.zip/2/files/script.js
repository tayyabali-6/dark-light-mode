let body = document.querySelector('body')

function darkMood() {
    body.style.backgroundColor = 'black'
    body.style.color = 'white'
    document.querySelector('.ri-contrast-2-fill').style.display= 'none'
    document.querySelector('.ri-sun-line').style.display= 'block'
}

function lightMood() {
    body.style.backgroundColor = 'white'
    body.style.color = 'black'
    document.querySelector('.ri-contrast-2-fill').style.display= 'block'
    document.querySelector('.ri-sun-line').style.display= 'none'
}



